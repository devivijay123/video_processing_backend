import { HttpStatusCodes } from "@constants/status_codes";
import { commitTransaction, getConnection, releaseConnection, rollBackTransaction } from "@db/helpers/transation";
import logger from "@logger";
import { IServiceResponse, ServiceResponse } from "@models";
import crypto from 'crypto';
import {  VideoData } from '@db/queries'
import * as tf from '@tensorflow/tfjs'; 
import '@tensorflow/tfjs-backend-webgl'; 
import * as cocoSsd from '@tensorflow-models/coco-ssd';
import ffmpeg from 'fluent-ffmpeg';
import ffmpegStatic from 'ffmpeg-static';
import path from 'path';
import { Readable } from 'stream';
import { createCanvas, loadImage } from 'canvas';
import { setWasmPaths } from '@tensorflow/tfjs-backend-wasm';
import fs from 'fs';
import { DIRECTORIES } from "@constants/file_constants";
import { saveFile, getFileUrl } from "@helpers/s3_media";
import { AWS_S3 } from "@config";
import * as nodeUtil from 'util'

const TAG = 'service.videos';


export async function saveVideo(payload: any): Promise<IServiceResponse> {
    logger.info(TAG + '.saveVideo()');
    const serviceResponse: IServiceResponse = new ServiceResponse(
        HttpStatusCodes.OK,
        'Video saved successfully'
    );

    let connection = null;
    const file = payload;
    const fileName = file.originalname;
    const filePath = file.path;


    try {
        
        connection = await getConnection(true);
        const fileDirectory =  DIRECTORIES.CONVOLVE_VIDEOS
        const data = await saveFile(file, fileDirectory, AWS_S3.bucketName)
        logger.debug(` ${TAG}.uploadimage 's3 response:'` + nodeUtil.inspect(data))
        logger.debug(
            ` ${TAG}.uploadimage 'fileS3 URL: ' ` + getFileUrl(data.savedFileKey, AWS_S3.bucketName)
        )
        
        const fileDetails = {
            fileName: data?.savedFileName,
            originalFileName: file?.originalname,
            contentType: file?.mimetype,
            s3Bucket: AWS_S3.bucketName,
            filePath: data?.savedFileKey,
            fileUrl: data?.savedLocation 
        }
        const videoId = await VideoData.saveVideoDetails(connection, fileDetails)
        await commitTransaction(connection);

        serviceResponse.data = {
            videoId,
            
        };

    } catch (error) {
        await rollBackTransaction(connection);
        
    
        logger.error(`ERROR in ${TAG}.saveVideo():`, error);
        serviceResponse.statusCode = HttpStatusCodes.INTERNAL_SERVER_ERROR;
        serviceResponse.message = 'Failed to process video';
        serviceResponse.addServerError(error.message);
    } finally {
        await releaseConnection(connection);
    }

    return serviceResponse;
}


