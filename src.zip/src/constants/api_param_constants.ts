
export const FormParams = {
    FILE_FIELD: 'video'
}