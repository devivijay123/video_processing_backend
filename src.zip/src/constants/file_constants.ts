export const DIRECTORIES = {
    CONVOLVE_VIDEOS : 'convolve_videos'
  }
  