
export const DEFAULT_ROUTE = `/api/v1`
export const ROUTER_VIDEO = `/video`;