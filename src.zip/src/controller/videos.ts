
import { responseBuilder } from "@helpers/response_builder";
import logger from "@logger";
import { IServiceResponse,  } from "@models";
import { NextFunction, Response } from "express";
import * as service from '@service/videos';

const TAG = 'controller.videos';

export async function saveVideo(req: any, res: Response, next: NextFunction): Promise<void> {
    logger.info(TAG + '.saveVideo() ');
    try {
        console.log("sudjas",req.file)
        logger.debug(`video object  ${JSON.stringify(req.file)}`);
        const response: IServiceResponse = await service.saveVideo(req.file);
        responseBuilder(response, res, next, req);
    } catch (error) {
        logger.error(`ERROR occurred in ${TAG}.saveVideo() `, error);
        next(error);
    }
}
