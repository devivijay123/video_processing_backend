import { Router } from "express";
import * as controller from '@controller/videos';
import multer from 'multer'
import { fileReader } from "@middleware/file_upload";
import { FormParams } from "@constants/api_param_constants";

const router = Router();

const upload = multer({ dest: 'uploads/' });

router.route('/upload')
    .post(fileReader(FormParams.FILE_FIELD),controller.saveVideo)
export default router;